export type Activity = {
    name: string,
    date: string | Date,
    manager: string,
};
