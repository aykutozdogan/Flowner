export type Note = {
    manager: string,
    date: string | Date,
    text: string
};

export type Notes = Note[];
