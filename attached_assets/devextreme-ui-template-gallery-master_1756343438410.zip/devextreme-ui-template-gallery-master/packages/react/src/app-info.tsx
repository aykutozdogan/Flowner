export const appInfo = {
  title: 'UI Template Gallery',
};
