export interface Note {
    text: string,
    date: string | Date,
    manager: string,
}

export type Notes = Note[];
