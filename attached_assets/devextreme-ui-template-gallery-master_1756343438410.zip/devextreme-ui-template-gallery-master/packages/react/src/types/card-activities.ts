export interface Activity {
    name: string,
    date: string | Date,
    manager: string,
}

export type Activities = Activity[];
