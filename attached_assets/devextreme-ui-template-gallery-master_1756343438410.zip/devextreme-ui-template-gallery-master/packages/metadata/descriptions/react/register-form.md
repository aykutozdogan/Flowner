The DevExtreme React Register Form template helps you implement a user registration workflow in your application.
<!--split-->

## UI Components  

- DevExtreme React Form – displays user properties as label/value pairs.

- DevExtreme React Button - allows users to submit credentials for registration.

## Usage Scenarios 

- Enter user credentials.

- Register a user (create a new user account).