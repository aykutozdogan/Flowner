The DevExtreme Angular Reset Password Form template helps you implement a user password reset workflow in your application.
<!--split-->

## UI Components  

- DevExtreme Angular Form – displays user properties as label/value pairs.

- DevExtreme Angular Button - allows users to submit credentials to be authenticated.

## Usage Scenarios 

- Enter credentials.

- Reset password.