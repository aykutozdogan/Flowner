The DevExtreme Angular Register Form template helps you implement a user registration workflow in your application.
<!--split-->

## UI Components  

- DevExtreme Angular Form – displays user properties as label/value pairs.

- DevExtreme Angular Button - allows users to submit credentials for registration.

## Usage Scenarios 

- Enter user credentials.

- Register a user (create a new user account).