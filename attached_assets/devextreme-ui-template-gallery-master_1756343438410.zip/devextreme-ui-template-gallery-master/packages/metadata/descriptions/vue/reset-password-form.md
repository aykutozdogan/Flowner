The DevExtreme Vue Reset Password Form template helps you implement a user password reset workflow in your application.
<!--split-->

## UI Components  

- DevExtreme Vue Form – displays user properties as label/value pairs.

- DevExtreme Vue Button - allows users to submit credentials to be authenticated.

## Usage Scenarios 

- Enter credentials.

- Reset password.