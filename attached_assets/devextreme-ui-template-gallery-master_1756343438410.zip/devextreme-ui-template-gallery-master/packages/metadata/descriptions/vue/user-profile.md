The DevExtreme Vue User Profile template helps you create an editing form for user's profile in your application.
<!--split-->

## UI Components  

- DevExtreme Vue Form – displays user properties as label/value pairs.

- DevExtreme Vue Button - allows users to cancel and save the changes.

## Usage Scenarios 

- Change user picture (user avatar).

- Change password.

- Edit profile data.

- Save profile data.

- Cancel data changes.